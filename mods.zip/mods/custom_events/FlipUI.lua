function onEvent(name, value1, value2)
if name == 'FlipUI' then
 doTweenAngle('bruh', 'camHUD', 180, 0.1, 'linear')

end
end